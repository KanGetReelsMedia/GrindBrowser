import React, { useState } from 'react';
import { ArrowUp, ArrowUpRight, Check, ChevronDown, Download, Flame, Layers, MonitorPlay, Play, Scissors, ShieldCheck, Sparkles, X, Zap } from 'lucide-react';

type Plan = { name: string; price: string; cadence: string; badge?: string; features: string[]; cta: string } | null;

const plans: Exclude<Plan, null>[] = [
  { name: 'FREE', price: '$0', cadence: 'forever', features: ['Full browser', 'Quad Grind', 'Split View', 'Clip 15s', 'Grind Stacks', 'Grind Vault', 'Red / White / Black themes'], cta: 'Download Free' },
  { name: 'PRO', price: '$4.99', cadence: '/month', features: ['Everything in Free', 'Priority creator matching', 'Unlimited Vault', 'Early features', 'Priority support'], cta: 'Buy Pro' },
  { name: 'LIFETIME', price: '$49', cadence: 'one-time', badge: 'Most Popular', features: ['Everything in Pro, forever', 'No subscription', 'Founding Grinder badge', 'Priority support'], cta: 'Buy Lifetime' },
];

const features = [
  { icon: Layers, title: 'Quad Grind', copy: 'Four live browser windows in one screen. Work, watch, research, and sell without tab chaos.' },
  { icon: MonitorPlay, title: 'Split View', copy: 'Put two tasks side by side and keep both in view while you grind.' },
  { icon: Zap, title: 'Grind Mode', copy: 'A focused layout that keeps your work front and center and cuts the noise.' },
  { icon: Scissors, title: 'Clip 15s', copy: 'Capture the exact 15 seconds that matter and keep the moment ready to share.' },
  { icon: Sparkles, title: 'Grind Stacks', copy: 'Save a whole workflow — every window, in order — and reopen it in one click.' },
  { icon: ShieldCheck, title: 'Grind Vault', copy: 'Save clips in a local vault. Your work stays organized and close at hand.' },
  { icon: Flame, title: 'Auto-Hide Address Bar', copy: 'More screen for the grind. The bar stays out of the way, never hides while typing.' },
  { icon: ShieldCheck, title: 'Privacy Shields', copy: 'Local Vault, Incognito, and controls for Downloads, History, and Bookmarks.' },
  { icon: Play, title: 'Red / White / Black Themes', copy: 'Pick the colorway that matches your setup. Bold, clean, and unmistakably Grind.' },
];

const faqs = [
  { q: 'Does it work like Chrome?', a: 'Yes. Grind Browser is built around familiar browsing — tabs, bookmarks, history, and downloads — with Quad Grind, Stacks, and Grind Mode layered on top.' },
  { q: 'Do I need PowerShell?', a: 'No. Download the setup file, double-click it, and install. No PowerShell. No code.' },
  { q: 'Does it work on another computer?', a: 'Yes. Install Grind Browser on any supported Windows 10/11 64-bit computer using the same setup file.' },
  { q: 'How do creators get paid?', a: 'Creators submit a YouTube or TikTok video and are matched with an advertiser. When the video plays in Grind with an opted-in ad, the creator earns. Advertisers only work with creators who are not already in the YouTube Partner Program.' },
];

function Logo() {
  return (
    <a href="#top" className="flex min-w-0 items-center gap-2.5" aria-label="Grind Browser home">
      <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-[var(--lime)] bg-black shadow-[0_0_0_3px_#09090b,0_0_24px_rgba(163,230,53,.25)]">
        <span className="font-display text-[20px] font-black leading-none text-[var(--lime)]">G</span>
        <ArrowUp className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-black text-[var(--lime)]" strokeWidth={3.5} />
      </span>
      <span className="font-display text-[19px] font-black leading-none tracking-[0.08em]">GRIND<span className="text-[var(--lime)]">.</span></span>
    </a>
  );
}

export default function App() {
  const [downloadOpen, setDownloadOpen] = useState(false);
  const [checkout, setCheckout] = useState<Exclude<Plan, null> | null>(null);
  const [openFaq, setOpenFaq] = useState(0);
  const [checkoutNote, setCheckoutNote] = useState('');

  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div data-safe-area-inset-root style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', minHeight: '100vh', background: 'var(--bg)' }} className="w-full overflow-x-clip text-[var(--text)]">
      {/* TOP NAV */}
      <header data-safe-area-sticky-top style={{ top: 'var(--safe-area-inset-top)' }} className="sticky z-40 border-b border-white/10 bg-[#09090b]/95 backdrop-blur">
        <div className="mx-auto flex h-[68px] max-w-[1200px] items-center justify-between gap-3 px-4 sm:px-6">
          <Logo />
          <nav className="hidden items-center gap-6 text-[13px] font-semibold tracking-wide lg:flex" aria-label="Main navigation">
            <button onClick={() => go('features')} className="hover:text-[var(--lime)]">Features</button>
            <button onClick={() => go('quad')} className="hover:text-[var(--lime)]">Quad Grind</button>
            <button onClick={() => go('creators')} className="hover:text-[var(--lime)]">Creator Monetization</button>
            <button onClick={() => go('pricing')} className="hover:text-[var(--lime)]">Pricing</button>
            <button onClick={() => go('faq')} className="hover:text-[var(--lime)]">FAQ</button>
          </nav>
          <button onClick={() => setDownloadOpen(true)} className="flex shrink-0 items-center gap-1.5 rounded-full bg-[var(--lime)] px-3 py-2.5 text-[13px] font-extrabold text-black hover:bg-[#bef264] sm:px-4">
            <Download className="h-4 w-4" /> <span className="hidden min-[420px]:inline">Download Free</span><span className="min-[420px]:hidden">Free</span>
          </button>
        </div>
        <div className="stripe stripe-thin" aria-hidden="true" />
        <nav className="flex gap-1 overflow-x-auto px-3 py-2 text-[12px] font-bold no-scrollbar lg:hidden" aria-label="Mobile navigation">
          {([['features','Features'],['quad','Quad Grind'],['creators','Creators'],['pricing','Pricing'],['faq','FAQ']] as const).map(([id,label]) => (
            <button key={id} onClick={() => go(id)} className="whitespace-nowrap rounded-full border border-white/15 px-3 py-1.5">{label}</button>
          ))}
        </nav>
      </header>

      <main id="top">
        {/* HERO */}
        <section className="relative overflow-x-clip">
          <div className="pointer-events-none absolute -left-24 top-16 h-72 w-72 rounded-full bg-[var(--lime)] opacity-[0.10] blur-[90px]" aria-hidden="true" />
          <div className="pointer-events-none absolute right-0 top-48 h-72 w-72 rounded-full bg-[var(--red)] opacity-[0.12] blur-[90px]" aria-hidden="true" />
          <div className="mx-auto max-w-[1200px] px-4 pb-14 pt-10 sm:px-6 sm:pt-16 lg:pb-20">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[var(--lime)]/40 bg-[var(--lime)]/10 px-3 py-1.5 text-[11px] font-bold tracking-[0.18em] text-[var(--lime)]">
              <span className="h-2 w-2 rounded-full bg-[var(--lime)]" /> BY KAN GET REAL MEDIA LLC
            </div>
            <h1 className="font-display max-w-[980px] text-balance text-[clamp(2.65rem,7.2vw,5.7rem)] font-black leading-[0.92] tracking-[-0.04em]">
              THE BROWSER<br />THAT <span className="text-[var(--lime)]">PAYS YOU</span><br />TO GRIND<span className="text-[var(--red)]">.</span>
            </h1>
            <p className="mt-6 max-w-[620px] text-[17px] leading-relaxed text-[#d4d4d8] sm:text-xl">4 windows. Red / White / Black. Built for creators who work harder.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <button onClick={() => setDownloadOpen(true)} className="flex items-center justify-center gap-2 rounded-full bg-[var(--lime)] px-6 py-4 text-[15px] font-extrabold text-black shadow-[0_12px_40px_rgba(163,230,53,.22)] hover:bg-[#bef264]">
                <Download className="h-5 w-5" /> Download for Windows — Free
              </button>
              <button onClick={() => go('quad')} className="flex items-center justify-center gap-2 rounded-full border border-white/25 bg-white/[0.04] px-6 py-4 text-[15px] font-bold hover:border-[var(--lime)]">
                See Quad Grind <ArrowUpRight className="h-5 w-5 text-[var(--lime)]" />
              </button>
            </div>
            <div className="mt-9 flex flex-wrap items-center gap-x-3 gap-y-3 border-t border-white/10 pt-5 text-[12px] font-medium text-[#a1a1aa] sm:text-[13px]">
              <span>Windows 10/11 • 64-bit • No PowerShell needed • Just double-click to install • By Kan Get Real Media LLC</span>
              <span className="flex items-center gap-1.5" aria-label="Available in red, white, and black">
                <span className="h-3.5 w-3.5 rounded-full border border-white/30 bg-[#ef4444]" /><span className="h-3.5 w-3.5 rounded-full border border-white/30 bg-white" /><span className="h-3.5 w-3.5 rounded-full border border-white/30 bg-black" />
              </span>
            </div>
            <div className="mt-8 grid grid-cols-3 gap-2 text-center sm:max-w-[620px]">
              {([['4','WINDOWS, ONE SCREEN'],['15s','CLIP & SAVE'],['$0','TO START']] as const).map(([n, label]) => (
                <div key={label} className="rounded-2xl border border-white/10 bg-white/[0.03] px-2 py-4">
                  <div className="font-display text-2xl font-black text-[var(--lime)] sm:text-3xl">{n}</div>
                  <div className="mt-1 text-[10px] font-bold tracking-[0.12em] text-[#a1a1aa]">{label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="stripe h-2" aria-hidden="true" />
        </section>

        {/* QUAD GRIND */}
        <section id="quad" className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 sm:py-20">
          <div className="grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="mb-3 text-[12px] font-black tracking-[0.22em] text-[var(--lime)]">QUAD GRIND</p>
              <h2 className="font-display text-balance text-[clamp(2rem,5vw,3.6rem)] font-black leading-[0.95] tracking-tight">4 browsers.<br />One screen.</h2>
              <p className="mt-5 max-w-[520px] leading-relaxed text-[#cbd5e1]">Stop losing your place across tabs. Quad Grind splits one window into four live workspaces — so research, notes, video, and your store stay open and in sync.</p>
              <ul className="mt-6 space-y-3 text-[15px]">
                {['Split your screen without losing your flow', 'Grind Mode keeps the task in front of you', 'Save the whole setup as a Grind Stack'].map((item) => (
                  <li key={item} className="flex gap-2.5"><Check className="mt-0.5 h-5 w-5 shrink-0 text-[var(--lime)]" /> <span>{item}</span></li>
                ))}
              </ul>
              <button onClick={() => setDownloadOpen(true)} className="mt-7 rounded-full bg-white px-5 py-3 text-sm font-extrabold text-black hover:bg-[var(--lime)]">Start grinding — it’s free</button>
            </div>

            <div className="rounded-[22px] border border-white/15 bg-[#17171a] p-2.5 shadow-2xl sm:p-3">
              <div className="flex items-center justify-between px-2 py-2">
                <div className="flex gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-[#ef4444]" /><span className="h-2.5 w-2.5 rounded-full bg-white" /><span className="h-2.5 w-2.5 rounded-full bg-black ring-1 ring-white/30" /></div>
                <span className="text-[11px] font-bold tracking-widest text-[#a1a1aa]">GRIND • QUAD VIEW</span>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
                {[
                  { label: 'YouTube', pos: 'Top-Left', border: 'border-[#ef4444]', dot: 'bg-[#ef4444]', body: '▶ Watch • Learn • Create', note: 'Your video, front and center.' },
                  { label: 'Research', pos: 'Top-Right', border: 'border-white', dot: 'bg-white', body: '◐ Compare • Read • Plan', note: 'Keep sources open beside it.' },
                  { label: 'Notes', pos: 'Bottom-Left', border: 'border-[#52525b]', dot: 'bg-zinc-500', body: '✎ Ideas • Scripts • Tasks', note: 'Capture it while it’s fresh.' },
                  { label: 'Store', pos: 'Bottom-Right', border: 'border-[#ef4444]', dot: 'bg-[#ef4444]', body: '⬢ Products • Orders • Sales', note: 'Sell while you work.' },
                ].map((w) => (
                  <article key={w.label} className={`min-w-0 rounded-xl border-2 bg-[#09090b] p-3 sm:p-4 ${w.border}`}>
                    <div className="flex items-center justify-between gap-2"><span className="text-[10px] font-bold tracking-[0.14em] text-[#a1a1aa]">{w.pos}</span><span className={`h-2 w-2 rounded-full ${w.dot}`} /></div>
                    <h3 className="font-display mt-5 text-lg font-black sm:mt-8 sm:text-xl">{w.label}</h3>
                    <p className="mt-1 break-words text-[12px] text-[#a1a1aa] sm:text-[13px]">{w.body}</p>
                    <p className="mt-3 hidden text-[12px] text-[#d4d4d8] sm:block">{w.note}</p>
                  </article>
                ))}
              </div>
              <p className="px-2 pb-1 pt-3 text-center text-[11px] font-bold tracking-[0.16em] text-[#a1a1aa]">RED • WHITE • BLACK • ONE GRIND</p>
            </div>
          </div>
        </section>

        {/* FEATURES */}
        <section id="features" className="border-y border-white/10 bg-[#0e0e10]">
          <div className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 sm:py-20">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div><p className="mb-3 text-[12px] font-black tracking-[0.22em] text-[var(--lime)]">BUILT TO WORK</p><h2 className="font-display text-[clamp(2rem,5vw,3.4rem)] font-black leading-none">Everything in<br />one grind.</h2></div>
              <p className="max-w-[360px] text-[15px] leading-relaxed text-[#a1a1aa]">No jumble. No extra setup. The tools you use every day, organized around the work itself.</p>
            </div>
            <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {features.map((f) => (
                <article key={f.title} className="group rounded-2xl border border-white/10 bg-[#17171a] p-5 hover:border-[var(--lime)]/60">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--lime)]/15 text-[var(--lime)]"><f.icon className="h-5 w-5" /></div>
                  <h3 className="font-display mt-4 text-lg font-extrabold">{f.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#a1a1aa]">{f.copy}</p>
                </article>
              ))}
              <article className="flex flex-col justify-between rounded-2xl bg-[var(--lime)] p-5 text-black sm:col-span-2 lg:col-span-1">
                <div><h3 className="font-display text-2xl font-black leading-tight">Ready to see it<br />in action?</h3><p className="mt-2 text-sm font-medium">Download free and open Quad Grind in minutes.</p></div>
                <button onClick={() => setDownloadOpen(true)} className="mt-5 flex items-center justify-center gap-2 rounded-full bg-black px-4 py-3 text-sm font-extrabold text-white">Download Free <Download className="h-4 w-4" /></button>
              </article>
            </div>
          </div>
        </section>

        {/* CREATOR MONETIZATION */}
        <section id="creators" className="relative overflow-x-clip">
          <div className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 sm:py-20">
            <div className="grid gap-10 lg:grid-cols-[1.05fr_0.95fr]">
              <div>
                <p className="mb-3 text-[12px] font-black tracking-[0.22em] text-[var(--red)]">CREATOR MONETIZATION</p>
                <h2 className="font-display text-balance text-[clamp(2rem,5vw,3.5rem)] font-black leading-[0.95]">Ad-first.<br />Creator-first.</h2>
                <p className="mt-5 max-w-[540px] leading-relaxed text-[#cbd5e1]">Grind Browser puts creators and advertisers on the same team. Creators submit YouTube or TikTok videos and are matched with advertisers. Ads show only if the channel or business opts in.</p>
                <div className="mt-6 rounded-2xl border border-[var(--red)]/40 bg-[var(--red)]/10 p-4 text-sm leading-relaxed">
                  <strong className="text-white">Important eligibility rule:</strong> to get an advertiser through Grind, a creator must <strong>not</strong> already be in the YouTube Partner Program.
                </div>
              </div>
              <div className="space-y-3">
                {[
                  ['01', 'Submit your video', 'Send in your YouTube or TikTok video and tell us what it’s about.'],
                  ['02', 'Get matched with an advertiser', 'We pair your video with an advertiser that fits your audience and content.'],
                  ['03', 'Earn when your video plays in Grind', 'When your matched video plays in Grind, you earn.'],
                ].map(([n, t, c]) => (
                  <div key={n} className="flex gap-4 rounded-2xl border border-white/10 bg-[#17171a] p-5">
                    <span className="font-display text-3xl font-black text-[var(--lime)]">{n}</span>
                    <div><h3 className="font-display text-lg font-extrabold">{t}</h3><p className="mt-1 text-sm leading-relaxed text-[#a1a1aa]">{c}</p></div>
                  </div>
                ))}
                <button onClick={() => go('pricing')} className="w-full rounded-full bg-[var(--lime)] py-4 text-sm font-extrabold text-black hover:bg-[#bef264]">Apply as a Creator</button>
                <p className="text-center text-xs text-[#a1a1aa]">Start with the free browser. Creator applications open inside Grind.</p>
              </div>
            </div>
          </div>
          <div className="stripe h-2" aria-hidden="true" />
        </section>

        {/* PRICING */}
        <section id="pricing" className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 sm:py-20">
          <div className="text-center"><p className="mb-3 text-[12px] font-black tracking-[0.22em] text-[var(--lime)]">PRICING</p><h2 className="font-display text-[clamp(2rem,5vw,3.4rem)] font-black leading-none">Start free.<br />Upgrade when ready.</h2></div>
          <div className="mt-10 grid items-stretch gap-4 md:grid-cols-3">
            {plans.map((p) => (
              <article key={p.name} className={`relative flex flex-col rounded-[24px] border p-6 ${p.name === 'LIFETIME' ? 'border-[var(--lime)] bg-[#17171a] shadow-[0_0_50px_rgba(163,230,53,.12)]' : 'border-white/12 bg-[#111113]'}`}>
                {p.badge && <span className="absolute -top-3 left-6 rounded-full bg-[var(--lime)] px-3 py-1 text-[11px] font-black tracking-wide text-black">{p.badge}</span>}
                <div className="flex items-center justify-between"><h3 className="font-display text-lg font-black tracking-wide">{p.name}</h3><span className="text-xs font-bold text-[#a1a1aa]">{p.cadence}</span></div>
                <div className="font-display mt-4 text-5xl font-black tracking-tight">{p.price}</div>
                <ul className="mt-6 flex-1 space-y-3 text-sm text-[#d4d4d8]">{p.features.map((f) => <li key={f} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[var(--lime)]" />{f}</li>)}</ul>
                <button onClick={() => p.name === 'FREE' ? setDownloadOpen(true) : setCheckout(p)} className={`mt-7 w-full rounded-full py-3.5 text-sm font-extrabold ${p.name === 'LIFETIME' ? 'bg-[var(--lime)] text-black hover:bg-[#bef264]' : 'bg-white text-black hover:bg-[var(--lime)]'}`}>{p.cta}</button>
              </article>
            ))}
          </div>
          <p className="mt-6 text-center text-sm text-[#a1a1aa]">Download Free first. Upgrade anytime inside the browser. <strong className="text-white">30-day money-back.</strong></p>
        </section>

        {/* INSTALL */}
        <section className="border-y border-white/10 bg-[#0e0e10]">
          <div className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 sm:py-20">
            <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]"><div><p className="mb-3 text-[12px] font-black tracking-[0.22em] text-[var(--lime)]">HOW INSTALL WORKS</p><h2 className="font-display text-[clamp(2rem,5vw,3.4rem)] font-black leading-[0.95]">Just like Chrome.<br />No PowerShell. No code.</h2><button onClick={() => setDownloadOpen(true)} className="mt-7 rounded-full bg-[var(--lime)] px-5 py-3 text-sm font-extrabold text-black">Download Setup</button></div>
              <ol className="grid gap-3 sm:grid-cols-3">
                {[['1','Download Setup','Get Grind Browser Setup 12.0.0.exe for Windows.'],['2','Double-click','Open the file and follow the short installer.'],['3','Grind','Open Grind Browser and set up Quad Grind.']].map(([n,t,c]) => (
                  <li key={n} className="rounded-2xl border border-white/10 bg-[#17171a] p-5"><span className="font-display text-4xl font-black text-[var(--lime)]">{n}</span><h3 className="font-display mt-4 text-lg font-extrabold">{t}</h3><p className="mt-2 text-sm leading-relaxed text-[#a1a1aa]">{c}</p></li>
                ))}
              </ol>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="mx-auto max-w-[900px] px-4 py-14 sm:px-6 sm:py-20">
          <p className="mb-3 text-center text-[12px] font-black tracking-[0.22em] text-[var(--lime)]">FAQ</p>
          <h2 className="font-display text-center text-[clamp(2rem,5vw,3.2rem)] font-black">Questions, answered.</h2>
          <div className="mt-9 space-y-3">
            {faqs.map((f, i) => (
              <div key={f.q} className="overflow-hidden rounded-2xl border border-white/10 bg-[#17171a]">
                <button onClick={() => setOpenFaq(openFaq === i ? -1 : i)} aria-expanded={openFaq === i} className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left">
                  <span className="font-display text-[16px] font-bold sm:text-lg">{f.q}</span><ChevronDown className={`h-5 w-5 shrink-0 text-[var(--lime)] transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && <p className="px-5 pb-5 text-sm leading-relaxed text-[#a1a1aa] sm:text-[15px]">{f.a}</p>}
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/10 bg-black">
        <div className="stripe h-2" aria-hidden="true" />
        <div className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6">
          <div className="flex flex-col gap-7 md:flex-row md:items-start md:justify-between">
            <div><Logo /><p className="mt-3 max-w-[340px] text-sm leading-relaxed text-[#a1a1aa]">The browser that pays you to grind. Four windows. One screen. Built for creators who work harder.</p></div>
            <nav className="grid grid-cols-2 gap-x-10 gap-y-2 text-sm font-semibold" aria-label="Footer navigation">
              <button onClick={() => go('features')} className="text-left hover:text-[var(--lime)]">Features</button>
              <button onClick={() => go('quad')} className="text-left hover:text-[var(--lime)]">Quad Grind</button>
              <button onClick={() => go('creators')} className="text-left hover:text-[var(--lime)]">Creator Monetization</button>
              <button onClick={() => go('pricing')} className="text-left hover:text-[var(--lime)]">Pricing</button>
              <button onClick={() => go('faq')} className="text-left hover:text-[var(--lime)]">FAQ</button>
              <button onClick={() => setDownloadOpen(true)} className="text-left hover:text-[var(--lime)]">Download Free</button>
            </nav>
          </div>
          <div className="mt-10 flex flex-col gap-2 border-t border-white/10 pt-5 text-xs text-[#71717a] sm:flex-row sm:justify-between"><span>© 2026 Kan Get Real Media LLC. All rights reserved.</span><span>Windows 10/11 • 64-bit • Grind Browser Setup 12.0.0.exe</span></div>
        </div>
      </footer>

      {/* DOWNLOAD MODAL */}
      {downloadOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label="Download Grind Browser">
          <div className="max-h-[92vh] w-full max-w-[560px] overflow-y-auto rounded-t-[24px] border border-white/15 bg-[#17171a] p-6 sm:rounded-[24px] sm:p-7">
            <div className="flex items-start justify-between gap-4"><div><span className="rounded-full bg-[var(--lime)]/15 px-3 py-1 text-[11px] font-black tracking-widest text-[var(--lime)]">FREE DOWNLOAD</span><h2 className="font-display mt-3 text-2xl font-black">Your installer is ready to link.</h2></div><button onClick={() => setDownloadOpen(false)} aria-label="Close download dialog" className="rounded-full border border-white/15 p-2 hover:bg-white/10"><X className="h-5 w-5" /></button></div>
            <div className="mt-5 rounded-xl border border-white/10 bg-black/40 p-4"><p className="text-xs font-bold tracking-wide text-[#a1a1aa]">INSTALLER FILE</p><p className="mt-1 break-words font-mono text-[15px] font-bold">Grind Browser Setup 12.0.0.exe</p><p className="mt-2 text-sm text-[#a1a1aa]">Windows 10/11 • 64-bit • Just double-click to install.</p></div>
            <ol className="mt-5 list-decimal space-y-2 pl-5 text-sm leading-relaxed text-[#d4d4d8]"><li>Upload <strong>Grind Browser Setup 12.0.0.exe</strong> to your host.</li><li>Copy the direct file link from your host.</li><li>Connect that link to this Download button to make it live.</li></ol>
            <p className="mt-4 rounded-xl bg-[var(--lime)]/10 p-3 text-sm text-[#d4d4d8]">Upload it to your host and link it here. Until the file is linked, this page is ready for launch.</p>
            <div className="mt-6 flex flex-col gap-2 sm:flex-row"><button onClick={() => setDownloadOpen(false)} className="flex-1 rounded-full bg-[var(--lime)] py-3 text-sm font-extrabold text-black">Got it</button><button onClick={() => { setDownloadOpen(false); go('pricing'); }} className="flex-1 rounded-full border border-white/20 py-3 text-sm font-bold">See pricing</button></div>
          </div>
        </div>
      )}

      {/* CHECKOUT MODAL */}
      {checkout && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={`Checkout for ${checkout.name}`}>
          <div className="max-h-[92vh] w-full max-w-[560px] overflow-y-auto rounded-t-[24px] border border-white/15 bg-[#17171a] p-6 sm:rounded-[24px] sm:p-7">
            <div className="flex items-start justify-between gap-4"><div><span className="rounded-full bg-[var(--lime)] px-3 py-1 text-[11px] font-black text-black">{checkout.name} — SELECTED</span><h2 className="font-display mt-3 text-2xl font-black">{checkout.name === 'PRO' ? 'Buy Pro' : 'Buy Lifetime'}</h2></div><button onClick={() => { setCheckout(null); setCheckoutNote(''); }} aria-label="Close checkout dialog" className="rounded-full border border-white/15 p-2 hover:bg-white/10"><X className="h-5 w-5" /></button></div>
            <div className="mt-5 flex items-end justify-between rounded-xl border border-[var(--lime)]/40 bg-black/30 p-4"><div><p className="text-xs font-bold tracking-wide text-[#a1a1aa]">TOTAL TODAY</p><p className="font-display text-3xl font-black">{checkout.price} <span className="text-base font-bold text-[#a1a1aa]">{checkout.cadence}</span></p></div><span className="text-right text-xs text-[#a1a1aa]">30-day<br />money-back</span></div>
            <ul className="mt-4 space-y-2 text-sm text-[#d4d4d8]">{checkout.features.map((f) => <li key={f} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 text-[var(--lime)]" />{f}</li>)}</ul>
            <div className="mt-5 rounded-xl border border-dashed border-white/25 p-4"><p className="text-sm font-bold">Checkout link placeholder</p><p className="mt-1 text-sm text-[#a1a1aa]">Add your Stripe or Gumroad product link here to accept payment.</p></div>
            <p className="mt-3 text-sm font-semibold text-[var(--lime)]">Connect Stripe to go live.</p>
            <button onClick={() => setCheckoutNote('Checkout is not live yet. Add your Stripe or Gumroad link to enable payment for this plan.')} className="mt-4 w-full rounded-full bg-[var(--lime)] py-3.5 text-sm font-extrabold text-black">Continue to Secure Checkout</button>
            {checkoutNote && <p role="status" className="mt-3 rounded-xl bg-white/5 p-3 text-sm text-[#d4d4d8]">{checkoutNote}</p>}
            <button onClick={() => { setCheckout(null); setCheckoutNote(''); }} className="mt-3 w-full py-2 text-sm font-bold text-[#a1a1aa]">Back to pricing</button>
          </div>
        </div>
      )}
    </div>
  );
}
